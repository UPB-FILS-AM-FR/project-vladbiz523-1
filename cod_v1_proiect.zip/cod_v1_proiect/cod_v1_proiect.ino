#include <LiquidCrystal.h>
#include <Servo.h>

// PINI
#define TRIG 9
#define ECHO 10
#define BUZZER 6
#define SERVO_PIN 8

// LCD: RS, E, D4, D5, D6, D7
LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

Servo servoMotor;

// Functie citire distanta
long readDistance() {
  digitalWrite(TRIG, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG, LOW);

  long duration = pulseIn(ECHO, HIGH);
  long distance = duration * 0.034 / 2;

  return distance;
}

void setup() {
  pinMode(TRIG, OUTPUT);
  pinMode(ECHO, INPUT);
  pinMode(BUZZER, OUTPUT);

  lcd.begin(16, 2);
  lcd.print("Pornire...");
  
  servoMotor.attach(SERVO_PIN);
  servoMotor.write(0);

  delay(2000);
  lcd.clear();
}

void loop() {
  long distance = readDistance();

  // Afisare distanta
  lcd.setCursor(0, 0);
  lcd.print("Dist: ");
  lcd.print(distance);
  lcd.print(" cm   ");

  // Logica alarma
  if (distance > 0 && distance < 15) {
    lcd.setCursor(0, 1);
    lcd.print("DO NOT TOUCH!");

    digitalWrite(BUZZER, HIGH);
    servoMotor.write(90);
  } else {
    lcd.setCursor(0, 1);
    lcd.print("Safe          ");

    digitalWrite(BUZZER, LOW);
    servoMotor.write(0);
  }

  delay(200);
}